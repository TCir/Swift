//
//  ViewController.swift
//  TreinandoScrollView
//
//  Created by Thiago Valentim on 14/03/22.
//

import UIKit

class ViewController: UIViewController {

   
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


}

