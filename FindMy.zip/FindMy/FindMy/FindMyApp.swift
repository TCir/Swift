//
//  FindMyApp.swift
//  FindMy
//
//  Created by Daniel Swift on 11/04/2021.
//

import SwiftUI

@main
struct FindMyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
