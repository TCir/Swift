//
//  ContentView.swift
//  FindMy
//
//  Created by Daniel Swift on 11/04/2021.
//

import SwiftUI


struct ContentView: View {
    @State  var addItem = false
    var body: some View {
           
        ZStack {
            Image(uiImage: #imageLiteral(resourceName: "IMG_908AFB51BB24-1")).resizable().edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        }.overlay(
            Group {
                if addItem {
                    SearchCard()
                        .transition(.moveAndFade)
                }
            }
            , alignment: .bottom).edgesIgnoringSafeArea(.bottom)
        .onTapGesture {
            withAnimation(Animation.easeIn) {
                addItem.toggle()
            }
        }
        .statusBar(hidden: true)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            
    }
}
extension AnyTransition {
    static var moveAndFade: AnyTransition {
        let insertion = AnyTransition.move(edge: .bottom)
            .combined(with: .identity)
        let removal = AnyTransition.move(edge: .bottom)
            .combined(with: .identity)
        return .asymmetric(insertion: insertion, removal: removal)
    }
}

struct SearchCard: View {
    
    @State private var shimmer: Bool = .random()
    @State var xoffset: CGFloat =  .random(in: -65...65)
    
    var body: some View {
           
        VStack {
            Circle().foregroundColor(.clear)
    
            Rectangle().foregroundColor(Color.init(.systemBackground))
                .frame(width: 300, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .overlay(
                    ZStack {
                    Image("item-background").resizable()
                        .frame(width: 300, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                         VStack {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 160))
                                .offset(x: 12.0, y: 12.0)
                                .frame(width: 800, height: 800, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                                .background(RadialGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 0)), Color.init(.systemBackground).opacity(0.9)]), center: .center, startRadius: 50, endRadius: 60))
                        }
                        .scaleEffect(shimmer ? 1 : 0.8)
                        .rotationEffect(Angle(degrees: shimmer ? 80 : 0))
                         .offset(x: shimmer ? -60 : 60, y: shimmer ? 10 : -10)
                }
                   )
            
        }
        .overlay(
            VStack(spacing: 10.0) {
            Text("Searching Item...")
                .font(.largeTitle).fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            Text("Follow the instructions provided by the manufactuer to make your item discoverable.")
                .font(.headline)
                .multilineTextAlignment(.center)
               
        }.padding(), alignment: .top)
        
        .overlay(Image(systemName: "xmark").padding(), alignment: .topTrailing)
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        .background(Color.init(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .onAppear {
            withAnimation(Animation.spring(response: 1, dampingFraction: 1, blendDuration: 1).repeatForever()) {
                shimmer.toggle()
            }
        }
    }
}
